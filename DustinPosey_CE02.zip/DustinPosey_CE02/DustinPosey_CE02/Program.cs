﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DustinPosey_CE02
{
    class Program
    {
        static void Main(string[] args)
        {

            
            Weapon UserW = new Weapon();

            bool looper = true;

            while (looper)
            {
                Console.WriteLine("1. Create Character");
                Console.WriteLine("2. Modify Character");
                Console.WriteLine("3. Create and Equip Weapon");
                Console.WriteLine("4. Display Character Data");
                Console.WriteLine("5. Exit");

                string userResponse = Console.ReadLine();
                userResponse = userResponse.ToLower ();

              

            if (userResponse == "1" || userResponse == "Create Character")

                {
                    Console.Write("Please enter your name:");
                    string username = Console.ReadLine();
                    Console.WriteLine("Please enter your race:");
                    string userRace = Console.ReadLine();
                    Console.WriteLine("Please enter your attack:");
                    string userAttack = Console.ReadLine();
                    int uattack = Convert.ToInt32(userAttack);
                    Console.WriteLine("Please enter the amount of health points your would like to start with:");
                    string userHealth = Console.ReadLine();
                    int uhealth = Convert.ToInt32(userHealth);
                    Console.WriteLine("Please enter your character's defense points:");
                    string userdefense = Console.ReadLine();
                    int udefense = Convert.ToInt32(userdefense);

                    Character C = new Character(username, uattack, uhealth, udefense, userRace);

                }
                else if (userResponse == "2" || userResponse == "Modify Character")

                {
                    Console.Write("Please new enter your name:");
                    string newusername = Console.ReadLine();
                    Console.WriteLine("Please enter your new race:");
                    string newuserRace = Console.ReadLine();
                    Console.WriteLine("Please enter your  new attack:");
                    string newuserAttack = Console.ReadLine();
                    int newuattack = Convert.ToInt32(newuserAttack);
                    Console.WriteLine("Please enter the new amount of health points for your character:");
                    string newuserHealth = Console.ReadLine();
                    int newuhealth = Convert.ToInt32(newuserHealth);
                    Console.WriteLine("Please enter your character's defense points:");
                    string newuserdefense = Console.ReadLine();
                    int newudefense = Convert.ToInt32(newuserdefense);

                    Character C = new Character(newusername, newuattack, newuhealth, newudefense, newuserRace);

                }
                else if (userResponse == "3" || userResponse == "Create and Equip Weapon")

                {
                    Console.WriteLine("Please enter your weapons attack value:");
                    string userWAttack = Console.ReadLine();
                    int uWAttack = Convert.ToInt32(userWAttack);
                    Console.WriteLine("Please enter your weapons parry value");
                    string userWParry = Console.ReadLine();
                    int uWParry = Convert.ToInt32(userWParry);

                    Weapon W = new Weapon(uWAttack, uWParry);

                }
                else if (userResponse == "4" || userResponse == "Display Character Data")
                    
                {
                    Character.characterStatDisplay();
                    UserW.weaponStatDisplay();
                    Console.ReadKey();
                }

                else if (userResponse == "5" || userResponse == "Exit")

                {
                    return;
                }    
                else
                {
                    looper = true;
                }


                
               
            }
        }
    }
}

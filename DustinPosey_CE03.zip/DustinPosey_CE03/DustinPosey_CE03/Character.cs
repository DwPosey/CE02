﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DustinPosey_CE03
{
    class Character
    {
        public string name;
        public int health;
        public string statusEffect; 

    public  Character()
        {
            name = "Pennywise";
            health = 100;
            statusEffect = null;
        }

        public Character(string cName, int cHealth, string cStatusEffect)
        {
            name = cName;
            health = cHealth;
            statusEffect = cStatusEffect;
        }

        public int cName { get { return cName; } set { cName = value; } }
        public int cHealth { get { return cHealth; } set { cHealth = value; } }
        public int cStatusEffect { get { return cStatusEffect; } set { cStatusEffect = value; } }

        public void characterStatDisplay()
        {
            Console.WriteLine("Name: {0} \r\nHealth: {1} \r\nStatus Effect: {2}" ,name, health, statusEffect);
        }
    }
}

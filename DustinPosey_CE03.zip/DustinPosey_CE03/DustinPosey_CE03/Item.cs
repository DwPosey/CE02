﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DustinPosey_CE03
{
    abstract class Item : IUsable  
    {
       

        protected int iEffect;
        protected string sEffect;
        protected string descrip;
        

        virtual public void Use(Character cParameter)
        {
            
        }

        public virtual void setIEffect(int intE)
        {
            iEffect = intE;
        }
        public virtual int getIEffect()
        {
            return iEffect;
        }

    }
}
 

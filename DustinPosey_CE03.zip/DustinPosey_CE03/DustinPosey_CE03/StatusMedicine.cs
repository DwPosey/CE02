﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DustinPosey_CE03
{
    class StatusMedicine : Item
    {

        public override void Use(Character statusEffect)
        {


        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DustinPosey_CE03
{
    class Program
    {
        static void Main(string[] args)

        {
            Character dCharacter = new Character();
            Potion cPotion = new Potion();

            bool looper = true;



            while (looper)
            {
                Console.WriteLine(dCharacter.name);

                Console.WriteLine("\r\n1. Character Status Display");
                Console.WriteLine("2. Set Character Status");
                Console.WriteLine("3. Use Potion");
                Console.WriteLine("4. Use Status Medicine");
                Console.WriteLine("5. Exit");
                string userResponse = Console.ReadLine();
                userResponse = userResponse.ToLower();

                if(userResponse == "1" || userResponse == "Character Status Display")
                {
                    dCharacter.characterStatDisplay();
                    Console.ReadKey();
                }

                else if (userResponse == "2" || userResponse == "Set Character Status")
                {
                    Console.WriteLine("Please enter your Character's Name:");
                    string newUName = Console.ReadLine();
                    dCharacter.name = newUName;
                    Console.WriteLine("Please enter an interger to represent your character's hit points");
                    string newUserHealth = Console.ReadLine();
                    int newUHealth;
                    while (!(int.TryParse(newUserHealth, out newUHealth)))
                    {
                        Console.WriteLine("Please type in an interger to represent your hit points to continue:");
                        newUserHealth = Console.ReadLine();
                        int.TryParse(newUserHealth, out newUHealth);
                    }
                    dCharacter.health = newUHealth;
                    Console.WriteLine("Please enter your character's status");
                    string newUStatus = Console.ReadLine();
                    dCharacter.statusEffect = newUStatus;
                }

                else if (userResponse == "3" || userResponse == "Use Potion")
                {
                    dCharacter.health += 10;
                    Console.WriteLine("You took a potion");
          
                }
                else if (userResponse == "4" || userResponse == "Status Potion")
                {
                    Console.WriteLine("What would you like to cure");
                    string userfix = Console.ReadLine();
                    Console.WriteLine("You cured " + userfix + "!");
                }

                else if (userResponse  == "5" || userResponse == "Exit")
                {
                    return;
                }
                else
                {
                    looper = true;
                }










            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DustinPosey_CE03
{

    class Potion : Item
    {
        public Potion() { 
        iEffect =33;
        sEffect =null;
        descrip = "You took a potion";
    }
        public Potion(int tIEffect, string tSEffect, string tDescrip)
        {
            iEffect = tIEffect;
            sEffect = tSEffect;
            descrip = tDescrip;
        }

        public override void Use(Character health)
        {

            

        }
        }
    }
}

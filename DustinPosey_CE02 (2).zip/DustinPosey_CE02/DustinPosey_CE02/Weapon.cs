﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DustinPosey_CE02
{
    public class Weapon
    {
        private int weaponAttack;
        private int weaponParry;

        public Weapon()
        {
            weaponAttack = 0;
            weaponParry = 0;
        }

        public Weapon(int attack, int parry)
        {
            weaponAttack = attack;
            weaponParry = parry;
        }

        public int attack {get { return attack; } set { attack = value; } }
        public int parry {get { return attack; } set { attack = value; } }

        public void weaponStatDisplay()
        {
            Console.WriteLine("Your weapon's current attack rating is {0} \r\nYour weapon's current parry rating is {1}", attack, parry);
        }

    }
}
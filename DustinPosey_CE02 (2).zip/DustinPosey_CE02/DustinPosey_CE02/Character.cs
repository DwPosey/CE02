﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DustinPosey_CE02
{
   public class Character
    {
        private string characterName;
        private int characterBaseAttack;
        private int characterHealth;
        private Weapon equippedWeapon;
        private int characterBaseDefense;
        private string characterRace; 

        public Character ()
        {
            characterName = null;
            characterBaseAttack = 0;
            characterHealth = 0;
            characterBaseDefense = 0;
            characterRace = null;
        }

        public Character(string name, int baseAttack, int health, int baseDefense, string race)
        {
            characterName = name;
            characterBaseAttack = baseAttack;
            characterHealth = health;
            characterBaseDefense = baseDefense;
            characterRace = race;
        }

        public string name { get { return name; } set {name = value; } }
        public int baseAttack { get { return baseAttack; } set { baseAttack = value; } }
        public int health { get { return health; } set { health = value; } }
        public int baseDefense { get { return baseDefense; } set { baseDefense = value; } }
        public string race { get { return race; } set { race = value; } }
        public Weapon equippedWeapon { get { return equippedWeapon; } set { equippedWeapon = value; } }

        static public void characterStatDisplay()
        {
            Console.WriteLine("Currently your are known as {0}. \r\nYour base attack is {1}. \r\nYou have {2} hit points. \r\nYour defense rating is {3}. \r\nYour race is {4}.", name, baseAttack, health, baseDefense, race);
     
        }
    }
}
